# MEAN-stack-DL
Digital Library prject in MEAN stack

To run locally:
<1>Clone this repo
<2>npm init
<3>npm install --save-dev @angular-devkit/core
<4>run mongodb server
<5>npm start
