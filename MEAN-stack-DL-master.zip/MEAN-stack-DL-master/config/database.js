module.exports = {
  'secret':'meansecure',
  'database': 'mongodb://localhost/mean-secure'
};
